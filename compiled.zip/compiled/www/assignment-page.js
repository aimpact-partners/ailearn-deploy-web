System.register(["@beyond-js/widgets@0.1.4/render", "@beyond-js/kernel@0.1.9/bundle", "react@18.2.0", "@ai-clase/demo@0.0.1/assistant", "@ai-clase/demo@0.0.1/assignments", "@beyond-js/react-18-widgets@0.0.5/page", "@beyond-js/kernel@0.1.9/styles"], function (_export, _context) {
  "use strict";

  var dependency_0, dependency_1, dependency_2, dependency_3, dependency_4, dependency_5, dependency_6, bimport, __Bundle, __pkg, ims, Controller, __beyond_pkg, hmr;
  _export("Controller", void 0);
  return {
    setters: [function (_beyondJsWidgets014Render) {
      dependency_0 = _beyondJsWidgets014Render;
    }, function (_beyondJsKernel019Bundle) {
      dependency_1 = _beyondJsKernel019Bundle;
    }, function (_react2) {
      dependency_2 = _react2;
    }, function (_aiClaseDemo001Assistant) {
      dependency_3 = _aiClaseDemo001Assistant;
    }, function (_aiClaseDemo001Assignments) {
      dependency_4 = _aiClaseDemo001Assignments;
    }, function (_beyondJsReact18Widgets005Page) {
      dependency_5 = _beyondJsReact18Widgets005Page;
    }, function (_beyondJsKernel019Styles) {
      dependency_6 = _beyondJsKernel019Styles;
    }],
    execute: function () {
      bimport = specifier => {
        const dependencies = new Map([["openai", "3.2.1"], ["@beyond-js/backend", "0.1.5"], ["@beyond-js/events", "0.0.6"], ["@beyond-js/kernel", "0.1.9"], ["@beyond-js/local", "0.1.3"], ["@beyond-js/widgets", "0.1.4"], ["@beyond-js/react-18-widgets", "0.0.5"], ["@types/dom-mediacapture-record", "1.0.14"], ["@google-cloud/error-reporting", "3.0.5"], ["uuid", "9.0.0"], ["firebase", "9.17.2"], ["@firebase/util", "1.9.3"], ["@firebase/logger", "0.4.0"], ["@firebase/component", "0.6.4"], ["@google-cloud/logging", "10.4.0"], ["firebase-admin", "11.5.0"], ["socket.io-client", "4.6.1"], ["@ai-clase/demo", "0.0.1"], ["@ai-clase/demo", "0.0.1"]]);
        return globalThis.bimport(globalThis.bimport.resolve(specifier, dependencies));
      };
      ({
        Bundle: __Bundle
      } = dependency_1);
      __pkg = new __Bundle({
        "module": {
          "vspecifier": "@ai-clase/demo@0.0.1/assignment-page"
        },
        "type": "widget"
      }, _context.meta.url).package();
      ;
      __pkg.dependencies.update([['@beyond-js/widgets/render', dependency_0], ['react', dependency_2], ['@ai-clase/demo/assistant', dependency_3], ['@ai-clase/demo/assignments', dependency_4], ['@beyond-js/react-18-widgets/page', dependency_5], ['@beyond-js/kernel/styles', dependency_6]]);
      brequire('@beyond-js/widgets/render').widgets.register([{
        "name": "assignment-page",
        "vspecifier": "@ai-clase/demo@0.0.1/assignment-page",
        "is": "page",
        "route": "/assignments/${assignment}"
      }]);
      brequire('@beyond-js/kernel/styles').styles.register('@ai-clase/demo@0.0.1/assignment-page');
      ims = new Map();
      /********************************************************
      INTERNAL MODULE: ./Assistant/LastMessage/AssistantMessage
      ********************************************************/
      ims.set('./Assistant/LastMessage/AssistantMessage', {
        hash: 3784705651,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var _react = require("react");
          const {
            useEffect,
            useState,
            useRef
          } = _react.default;
          const AssistantMessage = ({
            assistant,
            text
          }) => {
            const {
              voice
            } = assistant.conversation;
            const [isHidden, setIsHidden] = useState(false);
            const [, setIsPaused] = useState(false);
            const [, setCurrentWord] = useState(-1);
            const {
              reproduced,
              unreproduced
            } = (() => {
              if (!voice.speaking) return {
                reproduced: text,
                unreproduced: ''
              };
              const lastWordSize = text.slice(voice.currentWord).split(' ')[0].length;
              const reproduced = text.slice(0, voice.currentWord + lastWordSize);
              const unreproduced = text.slice(voice.currentWord + lastWordSize);
              return {
                reproduced,
                unreproduced
              };
            })();
            useEffect(() => {
              const update = () => {
                setCurrentWord(voice.currentWord);
                setIsPaused(voice.paused);
              };
              voice.on('change', update);
              return () => voice.off('change', update);
            });
            const container = useRef(null);
            useEffect(() => {
              const {
                current
              } = container;
              window.asd = current;
              const height = current.closest('.last-message-container').clientHeight;
              current.closest('.last').style.height = `${height}px`;
            }, [isHidden]);
            const handleHidden = isHidden => setIsHidden(isHidden);
            if (isHidden) return _react.default.createElement("div", {
              ref: container,
              className: "assistant-button",
              onClick: () => handleHidden(false)
            }, "Mostrar");
            const handleReproductionClick = () => {
              if (voice.paused) {
                voice.resume();
                return;
              }
              voice.speaking ? voice.pause() : voice.speak();
            };
            return _react.default.createElement("div", {
              ref: container
            }, _react.default.createElement("div", {
              className: "text"
            }, _react.default.createElement("span", {
              className: "reproduced"
            }, reproduced), _react.default.createElement("span", {
              className: "unreproduced"
            }, unreproduced)), _react.default.createElement("div", {
              className: "assistant-button",
              onClick: handleReproductionClick,
              disabled: voice.speaking
            }, voice.paused ? "Pausado" : voice.speaking ? "Reproduciendo …" : "Reproducir …"), _react.default.createElement("div", {
              className: "assistant-button"
            }, "Hyper real voice"), _react.default.createElement("div", {
              className: "assistant-button",
              onClick: () => handleHidden(true)
            }, "Ocultar"));
          };
          var _default = AssistantMessage;
          exports.default = _default;
        }
      });

      /*********************************************
      INTERNAL MODULE: ./Assistant/LastMessage/index
      *********************************************/

      ims.set('./Assistant/LastMessage/index', {
        hash: 2307372927,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          var _AssistantMessage = require("./AssistantMessage");
          const {
            useState,
            useEffect,
            useRef
          } = React;
          const LastMessage = ({
            assistant
          }) => {
            const {
              conversation
            } = assistant;
            const [userMessage, setUserMessage] = useState(conversation.lastMessage.user);
            const [assistantMessage, setAssistantMessage] = useState(conversation.lastMessage.assistant);
            const container = useRef(null);
            useEffect(() => {
              const handleChange = () => {
                const {
                  user,
                  assistant
                } = conversation.lastMessage;
                setUserMessage(user);
                setAssistantMessage(assistant);
              };
              conversation.on('change', handleChange);
              return () => conversation.off('change', handleChange);
            }, [conversation]);
            useEffect(() => {
              const {
                current
              } = container;
              const height = current.clientHeight;
              current.parentElement.style.height = `${height}px`;
            });
            return React.createElement("div", {
              className: "last-message-container",
              ref: container
            }, React.createElement("div", {
              className: "user-message"
            }, userMessage), React.createElement("div", {
              className: "assistant-message"
            }, React.createElement(_AssistantMessage.default, {
              assistant: assistant,
              text: assistantMessage
            })));
          };
          var _default = LastMessage;
          exports.default = _default;
        }
      });

      /************************************************
      INTERNAL MODULE: ./Assistant/Messages/UserMessage
      ************************************************/

      ims.set('./Assistant/Messages/UserMessage', {
        hash: 3534949266,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          var _UserMessageActions = require("./UserMessageActions");
          const {
            useState,
            useRef,
            useEffect
          } = React;
          const UserMessage = ({
            assistant,
            index,
            text
          }) => {
            const [isEditing, setIsEditing] = useState(false);
            const [showActions, setShowActions] = useState(false);
            const textRef = useRef(null);
            useEffect(() => {
              if (isEditing && textRef.current) {
                textRef.current.focus();
              }
            }, [isEditing]);
            const handleTextClick = () => {
              setIsEditing(true);
              setShowActions(true);
            };
            const handleConfirm = () => {
              assistant.conversation.update(index, textRef.current.innerText);
              setIsEditing(false);
              setShowActions(false);
            };
            const handleCancel = () => {
              setIsEditing(false);
              setShowActions(false);
            };
            const handleBlur = event => {
              const {
                relatedTarget: target
              } = event;
              if (!target || target.tagName === 'BUTTON' && target.closest('.user-message-actions')) return;
              handleCancel();
            };
            return React.createElement("div", {
              className: "message message-user"
            }, React.createElement("div", {
              key: "edited-text",
              className: `text ${isEditing ? 'editing' : ''}`,
              onClick: handleTextClick,
              contentEditable: isEditing,
              onBlur: handleBlur,
              ref: textRef,
              dangerouslySetInnerHTML: {
                __html: text
              }
            }), showActions && React.createElement(_UserMessageActions.default, {
              onConfirm: handleConfirm,
              onCancel: handleCancel,
              targetElement: textRef.current
            }));
          };
          var _default = UserMessage;
          exports.default = _default;
        }
      });

      /*******************************************************
      INTERNAL MODULE: ./Assistant/Messages/UserMessageActions
      *******************************************************/

      ims.set('./Assistant/Messages/UserMessageActions', {
        hash: 2333950730,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          const {
            useRef,
            useEffect
          } = React;
          const UserMessageActions = ({
            onConfirm,
            onCancel,
            targetElement
          }) => {
            const messageRef = useRef(null);
            const positionRef = useRef('bottom');
            useEffect(() => {
              const messageHeight = messageRef.current?.clientHeight || 0;
              const targetRect = targetElement.getBoundingClientRect();
              const bottomSpace = window.innerHeight - targetRect.bottom;
              const topSpace = targetRect.top;
              positionRef.current = bottomSpace > messageHeight || bottomSpace > topSpace ? 'bottom' : 'top';
            }, [targetElement]);
            return React.createElement("div", {
              className: `user-message-actions ${positionRef.current}`,
              ref: messageRef
            }, React.createElement("button", {
              className: "confirm-button",
              onClick: onConfirm
            }, "Confirm"), React.createElement("button", {
              className: "cancel-button",
              onClick: onCancel
            }, "Cancel"));
          };
          var _default = UserMessageActions;
          exports.default = _default;
        }
      });

      /******************************************
      INTERNAL MODULE: ./Assistant/Messages/index
      ******************************************/

      ims.set('./Assistant/Messages/index', {
        hash: 1912053337,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          var _UserMessage = require("./UserMessage");
          const {
            useEffect,
            useState
          } = React;
          const Conversation = ({
            assistant
          }) => {
            const {
              conversation
            } = assistant;
            const [messages, setMessages] = useState(conversation.messages);
            const [goalsShow, setGoalsShow] = useState(true);
            const {
              goals
            } = assistant.assignment;
            useEffect(() => {
              const handleChange = () => {
                setMessages(conversation.messages);
              };
              conversation.on('change', handleChange);
              return () => conversation.off('change', handleChange);
            }, [conversation]);
            const handleGoalsShow = () => setGoalsShow(!goalsShow);
            return React.createElement("div", {
              className: "conversation"
            }, React.createElement("div", {
              className: "goals-header"
            }, React.createElement("div", {
              className: "goals-title"
            }, goalsShow ? 'Objetivos:' : ''), React.createElement("div", {
              className: "goals-toggle",
              onClick: handleGoalsShow
            }, goalsShow ? 'Ocultar' : 'Mostrar objetivos')), goalsShow && React.createElement("div", {
              className: "goals"
            }, goals.split('\n').map((line, index) => {
              return React.createElement("p", {
                key: index
              }, line, index !== goals.split('\n').length - 1 && React.createElement("br", null));
            })), messages.map((message, index) => message.role === 'user' ? React.createElement(_UserMessage.default, {
              key: index,
              assistant: assistant,
              index: index,
              text: message.content
            }) : React.createElement("div", {
              key: index,
              className: `message message-${message.role}`
            }, message.content)));
          };
          var _default = Conversation;
          exports.default = _default;
        }
      });

      /************************************
      INTERNAL MODULE: ./Assistant/Recorder
      ************************************/

      ims.set('./Assistant/Recorder', {
        hash: 1601081205,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          const {
            useState,
            useEffect
          } = React;
          const Recorder = ({
            assistant
          }) => {
            const {
              recorder
            } = assistant;
            const [isRecording, setIsRecording] = useState(recorder.recording);
            const [isTranscribing, setIsTranscribing] = useState(recorder.transcribing);
            const handleStart = () => {
              !recorder.recording && recorder.record();
            };
            const handleStop = () => {
              recorder.stop();
            };
            const handleContextMenu = e => {
              e.preventDefault();
            };
            useEffect(() => {
              const handleChange = () => {
                setIsRecording(recorder.recording);
                setIsTranscribing(recorder.transcribing);
              };
              recorder.on('change', handleChange);
              return () => recorder.off('change', handleChange);
            }, [recorder]);
            const text = isRecording ? 'Escuchándote' : isTranscribing ? 'Transcribiendo' : 'Escuchar';
            return React.createElement("button", {
              className: `recorder-button ${isRecording || isTranscribing ? "recording" : ""}`,
              onMouseDown: handleStart,
              onMouseUp: handleStop,
              onTouchStart: handleStart,
              onTouchEnd: handleStop,
              onKeyDown: e => e.key === " " && handleStart(),
              onKeyUp: e => e.key === " " && handleStop(),
              onContextMenu: handleContextMenu
            }, text);
          };
          var _default = Recorder;
          exports.default = _default;
        }
      });

      /*********************************
      INTERNAL MODULE: ./Assistant/index
      *********************************/

      ims.set('./Assistant/index', {
        hash: 3142997542,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          var _Recorder = require("./Recorder");
          var _LastMessage = require("./LastMessage");
          var _Messages = require("./Messages");
          const AssistantComponent = ({
            assistant
          }) => {
            return React.createElement("div", {
              className: "assistant"
            }, React.createElement("div", {
              className: "messages"
            }, React.createElement(_Messages.default, {
              assistant: assistant
            })), React.createElement("div", {
              className: "recorder"
            }, React.createElement(_Recorder.default, {
              assistant: assistant
            })), React.createElement("div", {
              className: "last"
            }, React.createElement(_LastMessage.default, {
              assistant: assistant
            })));
          };
          var _default = AssistantComponent;
          exports.default = _default;
        }
      });

      /**********************
      INTERNAL MODULE: ./Page
      **********************/

      ims.set('./Page', {
        hash: 3673073757,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.default = void 0;
          var React = require("react");
          var _Assistant = require("./Assistant");
          var _assistant = require("@ai-clase/demo/assistant");
          var _assignments = require("@ai-clase/demo/assignments");
          const Page = ({
            uri: {
              vars
            }
          }) => {
            const assignment = _assignments.assignments.get(vars.get("assignment"));
            const assistant = assignment ? new _assistant.Assistant(assignment) : void 0;
            return assignment ? React.createElement(_Assistant.default, {
              assistant: assistant
            }) : "Assignment not found.";
          };
          var _default = Page;
          exports.default = _default;
        }
      });

      /***********************
      INTERNAL MODULE: ./index
      ***********************/

      ims.set('./index', {
        hash: 3212644890,
        creator: function (require, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true
          });
          exports.Controller = void 0;
          var _page = require("@beyond-js/react-18-widgets/page");
          var _Page = require("./Page");
          /*bundle*/
          class Controller extends _page.PageReactWidgetController {
            get Widget() {
              return _Page.default;
            }
          }
          exports.Controller = Controller;
        }
      });
      __pkg.exports.descriptor = [{
        "im": "./index",
        "from": "Controller",
        "name": "Controller"
      }];
      // Module exports
      __pkg.exports.process = function ({
        require,
        prop,
        value
      }) {
        (require || prop === 'Controller') && _export("Controller", Controller = require ? require('./index').Controller : value);
      };
      _export("__beyond_pkg", __beyond_pkg = __pkg);
      _export("hmr", hmr = new function () {
        this.on = (event, listener) => __pkg.hmr.on(event, listener);
        this.off = (event, listener) => __pkg.hmr.off(event, listener);
      }());
      __pkg.initialise(ims);
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1VBQUE7VUFHQSxNQUFNO1lBQUNBLFNBQVM7WUFBRUMsUUFBUTtZQUFFQztVQUFNLENBQUMsR0FBR0MsY0FBSztVQU8zQyxNQUFNQyxnQkFBZ0IsR0FBRyxDQUFDO1lBQUNDLFNBQVM7WUFBRUM7VUFBSSxDQUF3QixLQUFJO1lBQ2xFLE1BQU07Y0FBQ0M7WUFBSyxDQUFDLEdBQUdGLFNBQVMsQ0FBQ0csWUFBWTtZQUV0QyxNQUFNLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUdULFFBQVEsQ0FBQyxLQUFLLENBQUM7WUFDL0MsTUFBTSxHQUFHVSxXQUFXLENBQUMsR0FBR1YsUUFBUSxDQUFDLEtBQUssQ0FBQztZQUN2QyxNQUFNLEdBQUdXLGNBQWMsQ0FBQyxHQUFHWCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFdkMsTUFBTTtjQUFDWSxVQUFVO2NBQUVDO1lBQVksQ0FBQyxHQUFpRCxDQUFDLE1BQUs7Y0FDbkYsSUFBSSxDQUFDUCxLQUFLLENBQUNRLFFBQVEsRUFBRSxPQUFPO2dCQUFDRixVQUFVLEVBQUVQLElBQUk7Z0JBQUVRLFlBQVksRUFBRTtjQUFFLENBQUM7Y0FFaEUsTUFBTUUsWUFBWSxHQUFHVixJQUFJLENBQUNXLEtBQUssQ0FBQ1YsS0FBSyxDQUFDVyxXQUFXLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxNQUFNO2NBRXZFLE1BQU1QLFVBQVUsR0FBR1AsSUFBSSxDQUFDVyxLQUFLLENBQUMsQ0FBQyxFQUFFVixLQUFLLENBQUNXLFdBQVcsR0FBR0YsWUFBWSxDQUFDO2NBQ2xFLE1BQU1GLFlBQVksR0FBR1IsSUFBSSxDQUFDVyxLQUFLLENBQUNWLEtBQUssQ0FBQ1csV0FBVyxHQUFHRixZQUFZLENBQUM7Y0FDakUsT0FBTztnQkFBQ0gsVUFBVTtnQkFBRUM7Y0FBWSxDQUFDO1lBQ3JDLENBQUMsR0FBRztZQUVKZCxTQUFTLENBQUMsTUFBSztjQUNYLE1BQU1xQixNQUFNLEdBQUcsTUFBSztnQkFDaEJULGNBQWMsQ0FBQ0wsS0FBSyxDQUFDVyxXQUFXLENBQUM7Z0JBQ2pDUCxXQUFXLENBQUNKLEtBQUssQ0FBQ2UsTUFBTSxDQUFDO2NBQzdCLENBQUM7Y0FFRGYsS0FBSyxDQUFDZ0IsRUFBRSxDQUFDLFFBQVEsRUFBRUYsTUFBTSxDQUFDO2NBQzFCLE9BQU8sTUFBTWQsS0FBSyxDQUFDaUIsR0FBRyxDQUFDLFFBQVEsRUFBRUgsTUFBTSxDQUFDO1lBQzVDLENBQUMsQ0FBQztZQUVGLE1BQU1JLFNBQVMsR0FBR3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUM7WUFFOUJGLFNBQVMsQ0FBQyxNQUFLO2NBQ1gsTUFBTTtnQkFBQzBCO2NBQU8sQ0FBQyxHQUFHRCxTQUFTO2NBQzFCRSxNQUFjLENBQUNDLEdBQUcsR0FBR0YsT0FBTztjQUU3QixNQUFNRyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUNDLFlBQVk7Y0FDdEVMLE9BQU8sQ0FBQ0ksT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDRSxLQUFLLENBQUNILE1BQU0sR0FBRyxHQUFHQSxNQUFNLElBQUk7WUFDekQsQ0FBQyxFQUFFLENBQUNwQixRQUFRLENBQUMsQ0FBQztZQUVkLE1BQU13QixZQUFZLEdBQUl4QixRQUFRLElBQUtDLFdBQVcsQ0FBQ0QsUUFBUSxDQUFDO1lBRXhELElBQUlBLFFBQVEsRUFBRSxPQUNWTjtjQUFLK0IsR0FBRyxFQUFFVCxTQUFTO2NBQUVVLFNBQVMsRUFBQyxrQkFBa0I7Y0FBQ0MsT0FBTyxFQUFFLE1BQU1ILFlBQVksQ0FBQyxLQUFLO1lBQUMsYUFBZTtZQUd2RyxNQUFNSSx1QkFBdUIsR0FBRyxNQUFLO2NBQ2pDLElBQUk5QixLQUFLLENBQUNlLE1BQU0sRUFBRTtnQkFDZGYsS0FBSyxDQUFDK0IsTUFBTSxFQUFFO2dCQUNkOztjQUdKL0IsS0FBSyxDQUFDUSxRQUFRLEdBQUdSLEtBQUssQ0FBQ2dDLEtBQUssRUFBRSxHQUFHaEMsS0FBSyxDQUFDaUMsS0FBSyxFQUFFO1lBQ2xELENBQUM7WUFFRCxPQUNJckM7Y0FBSytCLEdBQUcsRUFBRVQ7WUFBUyxHQUNmdEI7Y0FBS2dDLFNBQVMsRUFBQztZQUFNLEdBQ2pCaEM7Y0FBTWdDLFNBQVMsRUFBQztZQUFZLEdBQUV0QixVQUFVLENBQVEsRUFDaERWO2NBQU1nQyxTQUFTLEVBQUM7WUFBYyxHQUFFckIsWUFBWSxDQUFRLENBQ2xELEVBRU5YO2NBQUtnQyxTQUFTLEVBQUMsa0JBQWtCO2NBQUNDLE9BQU8sRUFBRUMsdUJBQXVCO2NBQUVJLFFBQVEsRUFBRWxDLEtBQUssQ0FBQ1E7WUFBUSxHQUN2RlIsS0FBSyxDQUFDZSxNQUFNLEdBQUcsU0FBUyxHQUFJZixLQUFLLENBQUNRLFFBQVEsR0FBRyxpQkFBaUIsR0FBRyxjQUFlLENBQy9FLEVBQ05aO2NBQUtnQyxTQUFTLEVBQUM7WUFBa0Isc0JBQXVCLEVBQ3hEaEM7Y0FBS2dDLFNBQVMsRUFBQyxrQkFBa0I7Y0FBQ0MsT0FBTyxFQUFFLE1BQU1ILFlBQVksQ0FBQyxJQUFJO1lBQUMsYUFBZSxDQUNoRjtVQUVkLENBQUM7VUFBQyxlQUVhN0IsZ0JBQWdCO1VBQUFzQzs7Ozs7Ozs7Ozs7Ozs7Ozs7VUM5RS9CO1VBQ0E7VUFHQSxNQUFNO1lBQUN6QyxRQUFRO1lBQUVELFNBQVM7WUFBRUU7VUFBTSxDQUFDLEdBQUdDLEtBQUs7VUFNM0MsTUFBTXdDLFdBQVcsR0FBK0IsQ0FBQztZQUFDdEM7VUFBUyxDQUFtQixLQUFJO1lBQzlFLE1BQU07Y0FBQ0c7WUFBWSxDQUFDLEdBQUdILFNBQVM7WUFDaEMsTUFBTSxDQUFDdUMsV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBRzVDLFFBQVEsQ0FBQ08sWUFBWSxDQUFDc0MsV0FBVyxDQUFDQyxJQUFJLENBQUM7WUFDN0UsTUFBTSxDQUFDQyxnQkFBZ0IsRUFBRUMsbUJBQW1CLENBQUMsR0FBR2hELFFBQVEsQ0FBQ08sWUFBWSxDQUFDc0MsV0FBVyxDQUFDekMsU0FBUyxDQUFDO1lBRTVGLE1BQU1vQixTQUFTLEdBQUd2QixNQUFNLENBQUMsSUFBSSxDQUFDO1lBRTlCRixTQUFTLENBQUMsTUFBSztjQUNYLE1BQU1rRCxZQUFZLEdBQUcsTUFBSztnQkFDdEIsTUFBTTtrQkFBQ0gsSUFBSTtrQkFBRTFDO2dCQUFTLENBQUMsR0FBR0csWUFBWSxDQUFDc0MsV0FBVztnQkFDbERELGNBQWMsQ0FBQ0UsSUFBSSxDQUFDO2dCQUNwQkUsbUJBQW1CLENBQUM1QyxTQUFTLENBQUM7Y0FDbEMsQ0FBQztjQUVERyxZQUFZLENBQUNlLEVBQUUsQ0FBQyxRQUFRLEVBQUUyQixZQUFZLENBQUM7Y0FDdkMsT0FBTyxNQUFNMUMsWUFBWSxDQUFDZ0IsR0FBRyxDQUFDLFFBQVEsRUFBRTBCLFlBQVksQ0FBQztZQUN6RCxDQUFDLEVBQUUsQ0FBQzFDLFlBQVksQ0FBQyxDQUFDO1lBRWxCUixTQUFTLENBQUMsTUFBSztjQUNYLE1BQU07Z0JBQUMwQjtjQUFPLENBQUMsR0FBR0QsU0FBUztjQUMzQixNQUFNSSxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ssWUFBWTtjQUNuQ0wsT0FBTyxDQUFDeUIsYUFBYSxDQUFDbkIsS0FBSyxDQUFDSCxNQUFNLEdBQUcsR0FBR0EsTUFBTSxJQUFJO1lBQ3RELENBQUMsQ0FBQztZQUVGLE9BQ0kxQjtjQUFLZ0MsU0FBUyxFQUFDLHdCQUF3QjtjQUFDRCxHQUFHLEVBQUVUO1lBQVMsR0FDbER0QjtjQUFLZ0MsU0FBUyxFQUFDO1lBQWMsR0FBRVMsV0FBVyxDQUFPLEVBQ2pEekM7Y0FBS2dDLFNBQVMsRUFBQztZQUFtQixHQUFDaEMsb0JBQUNDLHlCQUFnQjtjQUFDQyxTQUFTLEVBQUVBLFNBQVM7Y0FBRUMsSUFBSSxFQUFFMEM7WUFBZ0IsRUFBRyxDQUFNLENBQ3hHO1VBRWQsQ0FBQztVQUFDLGVBRWFMLFdBQVc7VUFBQUQ7Ozs7Ozs7Ozs7Ozs7Ozs7O1VDMUMxQjtVQUVBO1VBRUEsTUFBTTtZQUFDekMsUUFBUTtZQUFFQyxNQUFNO1lBQUVGO1VBQVMsQ0FBQyxHQUFHRyxLQUFLO1VBUTNDLE1BQU1pRCxXQUFXLEdBQW9CLENBQUM7WUFBQy9DLFNBQVM7WUFBRWdELEtBQUs7WUFBRS9DO1VBQUksQ0FBUSxLQUFJO1lBQ3JFLE1BQU0sQ0FBQ2dELFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUd0RCxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQ2pELE1BQU0sQ0FBQ3VELFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUd4RCxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQ3JELE1BQU15RCxPQUFPLEdBQUd4RCxNQUFNLENBQWlCLElBQUksQ0FBQztZQUU1Q0YsU0FBUyxDQUFDLE1BQUs7Y0FDWCxJQUFJc0QsU0FBUyxJQUFJSSxPQUFPLENBQUNoQyxPQUFPLEVBQUU7Z0JBQzlCZ0MsT0FBTyxDQUFDaEMsT0FBTyxDQUFDaUMsS0FBSyxFQUFFOztZQUUvQixDQUFDLEVBQUUsQ0FBQ0wsU0FBUyxDQUFDLENBQUM7WUFFZixNQUFNTSxlQUFlLEdBQUcsTUFBSztjQUN6QkwsWUFBWSxDQUFDLElBQUksQ0FBQztjQUNsQkUsY0FBYyxDQUFDLElBQUksQ0FBQztZQUN4QixDQUFDO1lBRUQsTUFBTUksYUFBYSxHQUFHLE1BQUs7Y0FDdkJ4RCxTQUFTLENBQUNHLFlBQVksQ0FBQ2EsTUFBTSxDQUFDZ0MsS0FBSyxFQUFFSyxPQUFPLENBQUNoQyxPQUFPLENBQUNvQyxTQUFTLENBQUM7Y0FDL0RQLFlBQVksQ0FBQyxLQUFLLENBQUM7Y0FDbkJFLGNBQWMsQ0FBQyxLQUFLLENBQUM7WUFDekIsQ0FBQztZQUVELE1BQU1NLFlBQVksR0FBRyxNQUFLO2NBQ3RCUixZQUFZLENBQUMsS0FBSyxDQUFDO2NBQ25CRSxjQUFjLENBQUMsS0FBSyxDQUFDO1lBQ3pCLENBQUM7WUFFRCxNQUFNTyxVQUFVLEdBQUdDLEtBQUssSUFBRztjQUN2QixNQUFNO2dCQUFDQyxhQUFhLEVBQUVDO2NBQU0sQ0FBQyxHQUFHRixLQUFLO2NBQ3JDLElBQUksQ0FBQ0UsTUFBTSxJQUFLQSxNQUFNLENBQUNDLE9BQU8sS0FBSyxRQUFRLElBQUlELE1BQU0sQ0FBQ3JDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBRSxFQUFFO2NBQ3pGaUMsWUFBWSxFQUFFO1lBQ2xCLENBQUM7WUFFRCxPQUNJNUQ7Y0FBS2dDLFNBQVMsRUFBQztZQUFzQixHQUNqQ2hDO2NBQ0lrRSxHQUFHLEVBQUMsYUFBYTtjQUNqQmxDLFNBQVMsRUFBRSxRQUFRbUIsU0FBUyxHQUFHLFNBQVMsR0FBRyxFQUFFLEVBQUU7Y0FDL0NsQixPQUFPLEVBQUV3QixlQUFlO2NBQ3hCVSxlQUFlLEVBQUVoQixTQUFTO2NBQzFCaUIsTUFBTSxFQUFFUCxVQUFVO2NBQ2xCOUIsR0FBRyxFQUFFd0IsT0FBTztjQUNaYyx1QkFBdUIsRUFBRTtnQkFBQ0MsTUFBTSxFQUFFbkU7Y0FBSTtZQUFDLEVBQ3JDLEVBQ0xrRCxXQUFXLElBQ1JyRCxvQkFBQ3VFLDJCQUFrQjtjQUNmQyxTQUFTLEVBQUVkLGFBQWE7Y0FDeEJlLFFBQVEsRUFBRWIsWUFBWTtjQUN0QmMsYUFBYSxFQUFFbkIsT0FBTyxDQUFDaEM7WUFBc0IsRUFFcEQsQ0FDQztVQUVkLENBQUM7VUFBQyxlQUVhMEIsV0FBVztVQUFBVjs7Ozs7Ozs7Ozs7Ozs7Ozs7VUNuRTFCO1VBUUEsTUFBTTtZQUFDeEMsTUFBTTtZQUFFRjtVQUFTLENBQUMsR0FBR0csS0FBSztVQUVqQyxNQUFNdUUsa0JBQWtCLEdBQW9CLENBQUM7WUFBQ0MsU0FBUztZQUFFQyxRQUFRO1lBQUVDO1VBQWEsQ0FBUSxLQUFJO1lBQ3hGLE1BQU1DLFVBQVUsR0FBRzVFLE1BQU0sQ0FBaUIsSUFBSSxDQUFDO1lBQy9DLE1BQU02RSxXQUFXLEdBQUc3RSxNQUFNLENBQW1CLFFBQVEsQ0FBQztZQUV0REYsU0FBUyxDQUFDLE1BQUs7Y0FDWCxNQUFNZ0YsYUFBYSxHQUFHRixVQUFVLENBQUNwRCxPQUFPLEVBQUVLLFlBQVksSUFBSSxDQUFDO2NBQzNELE1BQU1rRCxVQUFVLEdBQUdKLGFBQWEsQ0FBQ0sscUJBQXFCLEVBQUU7Y0FDeEQsTUFBTUMsV0FBVyxHQUFHeEQsTUFBTSxDQUFDeUQsV0FBVyxHQUFHSCxVQUFVLENBQUNJLE1BQU07Y0FDMUQsTUFBTUMsUUFBUSxHQUFHTCxVQUFVLENBQUNNLEdBQUc7Y0FFL0JSLFdBQVcsQ0FBQ3JELE9BQU8sR0FBR3lELFdBQVcsR0FBR0gsYUFBYSxJQUFJRyxXQUFXLEdBQUdHLFFBQVEsR0FBRyxRQUFRLEdBQUcsS0FBSztZQUNsRyxDQUFDLEVBQUUsQ0FBQ1QsYUFBYSxDQUFDLENBQUM7WUFFbkIsT0FDSTFFO2NBQUtnQyxTQUFTLEVBQUUsd0JBQXdCNEMsV0FBVyxDQUFDckQsT0FBTyxFQUFFO2NBQUVRLEdBQUcsRUFBRTRDO1lBQVUsR0FDMUUzRTtjQUFRZ0MsU0FBUyxFQUFDLGdCQUFnQjtjQUFDQyxPQUFPLEVBQUV1QztZQUFTLGFBQWtCLEVBQ3ZFeEU7Y0FBUWdDLFNBQVMsRUFBQyxlQUFlO2NBQUNDLE9BQU8sRUFBRXdDO1lBQVEsWUFBaUIsQ0FDbEU7VUFFZCxDQUFDO1VBQUMsZUFFYUYsa0JBQWtCO1VBQUFoQzs7Ozs7Ozs7Ozs7Ozs7Ozs7VUMvQmpDO1VBRUE7VUFFQSxNQUFNO1lBQUMxQyxTQUFTO1lBQUVDO1VBQVEsQ0FBQyxHQUFHRSxLQUFLO1VBTW5DLE1BQU1xRixZQUFZLEdBQWlDLENBQUM7WUFBQ25GO1VBQVMsQ0FBQyxLQUFJO1lBQy9ELE1BQU07Y0FBQ0c7WUFBWSxDQUFDLEdBQUdILFNBQVM7WUFDaEMsTUFBTSxDQUFDb0YsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBR3pGLFFBQVEsQ0FBQ08sWUFBWSxDQUFDaUYsUUFBUSxDQUFDO1lBQy9ELE1BQU0sQ0FBQ0UsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRzNGLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDaEQsTUFBTTtjQUFDNEY7WUFBSyxDQUFDLEdBQUd4RixTQUFTLENBQUN5RixVQUFVO1lBRXBDOUYsU0FBUyxDQUFDLE1BQUs7Y0FDWCxNQUFNa0QsWUFBWSxHQUFHLE1BQUs7Z0JBQ3RCd0MsV0FBVyxDQUFDbEYsWUFBWSxDQUFDaUYsUUFBUSxDQUFDO2NBQ3RDLENBQUM7Y0FFRGpGLFlBQVksQ0FBQ2UsRUFBRSxDQUFDLFFBQVEsRUFBRTJCLFlBQVksQ0FBQztjQUN2QyxPQUFPLE1BQU0xQyxZQUFZLENBQUNnQixHQUFHLENBQUMsUUFBUSxFQUFFMEIsWUFBWSxDQUFDO1lBQ3pELENBQUMsRUFBRSxDQUFDMUMsWUFBWSxDQUFDLENBQUM7WUFFbEIsTUFBTXVGLGVBQWUsR0FBRyxNQUFNSCxZQUFZLENBQUMsQ0FBQ0QsU0FBUyxDQUFDO1lBRXRELE9BQ0l4RjtjQUFLZ0MsU0FBUyxFQUFDO1lBQWMsR0FDekJoQztjQUFLZ0MsU0FBUyxFQUFDO1lBQWMsR0FDekJoQztjQUFLZ0MsU0FBUyxFQUFDO1lBQWEsR0FBRXdELFNBQVMsR0FBRyxZQUFZLEdBQUcsRUFBRSxDQUFPLEVBQ2xFeEY7Y0FBS2dDLFNBQVMsRUFBQyxjQUFjO2NBQ3hCQyxPQUFPLEVBQUUyRDtZQUFlLEdBQUdKLFNBQVMsR0FBRyxTQUFTLEdBQUcsbUJBQW1CLENBQU8sQ0FDaEYsRUFFTEEsU0FBUyxJQUFJeEY7Y0FBS2dDLFNBQVMsRUFBQztZQUFPLEdBQy9CMEQsS0FBSyxDQUFDMUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDNkUsR0FBRyxDQUFDLENBQUNDLElBQUksRUFBRTVDLEtBQUssS0FBSTtjQUNuQyxPQUNJbEQ7Z0JBQUdrRSxHQUFHLEVBQUVoQjtjQUFLLEdBQ1I0QyxJQUFJLEVBQ0o1QyxLQUFLLEtBQUt3QyxLQUFLLENBQUMxRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUNDLE1BQU0sR0FBRyxDQUFDLElBQUlqQiwrQkFBSyxDQUNoRDtZQUVaLENBQUMsQ0FBQyxDQUNBLEVBRUxzRixRQUFRLENBQUNPLEdBQUcsQ0FBQyxDQUFDRSxPQUFPLEVBQUU3QyxLQUFLLEtBQ3pCNkMsT0FBTyxDQUFDQyxJQUFJLEtBQUssTUFBTSxHQUNuQmhHLG9CQUFDaUQsb0JBQVc7Y0FBQ2lCLEdBQUcsRUFBRWhCLEtBQUs7Y0FBRWhELFNBQVMsRUFBRUEsU0FBUztjQUFFZ0QsS0FBSyxFQUFFQSxLQUFLO2NBQUUvQyxJQUFJLEVBQUU0RixPQUFPLENBQUNFO1lBQU8sRUFBRyxHQUNyRmpHO2NBQUtrRSxHQUFHLEVBQUVoQixLQUFLO2NBQUVsQixTQUFTLEVBQUUsbUJBQW1CK0QsT0FBTyxDQUFDQyxJQUFJO1lBQUUsR0FBR0QsT0FBTyxDQUFDRSxPQUFPLENBQ3RGLENBQUMsQ0FDQTtVQUVkLENBQUM7VUFBQyxlQUVhWixZQUFZO1VBQUE5Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7VUN2RDNCO1VBR0EsTUFBTTtZQUFDekMsUUFBUTtZQUFFRDtVQUFTLENBQUMsR0FBR0csS0FBSztVQU1uQyxNQUFNa0csUUFBUSxHQUFHLENBQUM7WUFBQ2hHO1VBQVMsQ0FBZ0IsS0FBSTtZQUM1QyxNQUFNO2NBQUNpRztZQUFRLENBQUMsR0FBR2pHLFNBQVM7WUFFNUIsTUFBTSxDQUFDa0csV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBR3ZHLFFBQVEsQ0FBQ3FHLFFBQVEsQ0FBQ0csU0FBUyxDQUFDO1lBQ2xFLE1BQU0sQ0FBQ0MsY0FBYyxFQUFFQyxpQkFBaUIsQ0FBQyxHQUFHMUcsUUFBUSxDQUFDcUcsUUFBUSxDQUFDTSxZQUFZLENBQUM7WUFFM0UsTUFBTUMsV0FBVyxHQUFHLE1BQUs7Y0FDckIsQ0FBQ1AsUUFBUSxDQUFDRyxTQUFTLElBQUlILFFBQVEsQ0FBQ1EsTUFBTSxFQUFFO1lBQzVDLENBQUM7WUFFRCxNQUFNQyxVQUFVLEdBQUcsTUFBSztjQUNwQlQsUUFBUSxDQUFDVSxJQUFJLEVBQUU7WUFDbkIsQ0FBQztZQUVELE1BQU1DLGlCQUFpQixHQUFJQyxDQUFzQyxJQUFJO2NBQ2pFQSxDQUFDLENBQUNDLGNBQWMsRUFBRTtZQUN0QixDQUFDO1lBRURuSCxTQUFTLENBQUMsTUFBSztjQUNYLE1BQU1rRCxZQUFZLEdBQUcsTUFBSztnQkFDdEJzRCxjQUFjLENBQUNGLFFBQVEsQ0FBQ0csU0FBUyxDQUFDO2dCQUNsQ0UsaUJBQWlCLENBQUNMLFFBQVEsQ0FBQ00sWUFBWSxDQUFDO2NBQzVDLENBQUM7Y0FFRE4sUUFBUSxDQUFDL0UsRUFBRSxDQUFDLFFBQVEsRUFBRTJCLFlBQVksQ0FBQztjQUNuQyxPQUFPLE1BQU1vRCxRQUFRLENBQUM5RSxHQUFHLENBQUMsUUFBUSxFQUFFMEIsWUFBWSxDQUFDO1lBQ3JELENBQUMsRUFBRSxDQUFDb0QsUUFBUSxDQUFDLENBQUM7WUFFZCxNQUFNaEcsSUFBSSxHQUFHaUcsV0FBVyxHQUFHLGNBQWMsR0FBSUcsY0FBYyxHQUFHLGdCQUFnQixHQUFHLFVBQVc7WUFFNUYsT0FDSXZHO2NBQ0lnQyxTQUFTLEVBQUUsbUJBQW1Cb0UsV0FBVyxJQUFJRyxjQUFjLEdBQUcsV0FBVyxHQUFHLEVBQUUsRUFBRTtjQUNoRlUsV0FBVyxFQUFFUCxXQUFXO2NBQ3hCUSxTQUFTLEVBQUVOLFVBQVU7Y0FDckJPLFlBQVksRUFBRVQsV0FBVztjQUN6QlUsVUFBVSxFQUFFUixVQUFVO2NBQ3RCUyxTQUFTLEVBQUdOLENBQUMsSUFBS0EsQ0FBQyxDQUFDN0MsR0FBRyxLQUFLLEdBQUcsSUFBSXdDLFdBQVcsRUFBRTtjQUNoRFksT0FBTyxFQUFHUCxDQUFDLElBQUtBLENBQUMsQ0FBQzdDLEdBQUcsS0FBSyxHQUFHLElBQUkwQyxVQUFVLEVBQUU7Y0FDN0NXLGFBQWEsRUFBRVQ7WUFBaUIsR0FFL0IzRyxJQUFJLENBQ0E7VUFFakIsQ0FBQztVQUFDLGVBRWErRixRQUFRO1VBQUEzRDs7Ozs7Ozs7Ozs7Ozs7Ozs7VUN2RHZCO1VBQ0E7VUFDQTtVQUNBO1VBT0EsTUFBTWlGLGtCQUFrQixHQUFhLENBQUM7WUFBQ3RIO1VBQVMsQ0FBaUIsS0FBSTtZQUNqRSxPQUNJRjtjQUFLZ0MsU0FBUyxFQUFDO1lBQVcsR0FDdEJoQztjQUFLZ0MsU0FBUyxFQUFDO1lBQVUsR0FBQ2hDLG9CQUFDeUgsaUJBQVE7Y0FBQ3ZILFNBQVMsRUFBRUE7WUFBUyxFQUFHLENBQU0sRUFDakVGO2NBQUtnQyxTQUFTLEVBQUM7WUFBVSxHQUFDaEMsb0JBQUNrRyxpQkFBUTtjQUFDaEcsU0FBUyxFQUFFQTtZQUFTLEVBQUcsQ0FBTSxFQUNqRUY7Y0FBS2dDLFNBQVMsRUFBQztZQUFNLEdBQ2pCaEMsb0JBQUN3QyxvQkFBVztjQUFDdEMsU0FBUyxFQUFFQTtZQUFTLEVBQUcsQ0FDbEMsQ0FDSjtVQUVkLENBQUM7VUFBQyxlQUVhc0gsa0JBQWtCO1VBQUFqRjs7Ozs7Ozs7Ozs7Ozs7Ozs7VUN0QmpDO1VBQ0E7VUFDQTtVQUNBO1VBTUEsTUFBTW1GLElBQUksR0FBRyxDQUFDO1lBQUVDLEdBQUcsRUFBRTtjQUFFQztZQUFJO1VBQUUsQ0FBYSxLQUFJO1lBQzVDLE1BQU1qQyxVQUFVLEdBQUdrQyx3QkFBVyxDQUFDQyxHQUFHLENBQUNGLElBQUksQ0FBQ0UsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzFELE1BQU01SCxTQUFTLEdBQUd5RixVQUFVLEdBQUcsSUFBSW9DLG9CQUFTLENBQUNwQyxVQUFVLENBQUMsR0FBRyxLQUFLLENBQUM7WUFFakUsT0FBT0EsVUFBVSxHQUFHM0Ysb0JBQUN3SCxrQkFBa0I7Y0FBQ3RILFNBQVMsRUFBRUE7WUFBUyxFQUFJLEdBQUcsdUJBQXVCO1VBQzVGLENBQUM7VUFBQyxlQUVhd0gsSUFBSTtVQUFBbkY7Ozs7Ozs7Ozs7Ozs7Ozs7O1VDaEJuQjtVQUNBO1VBRU87VUFBVSxNQUNYeUYsVUFBVyxTQUFRQywrQkFBeUI7WUFDaEQsSUFBSUMsTUFBTTtjQUNSLE9BQU9SLGFBQUk7WUFDYjs7VUFDRG5GIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJSZWFjdCIsIkFzc2lzdGFudE1lc3NhZ2UiLCJhc3Npc3RhbnQiLCJ0ZXh0Iiwidm9pY2UiLCJjb252ZXJzYXRpb24iLCJpc0hpZGRlbiIsInNldElzSGlkZGVuIiwic2V0SXNQYXVzZWQiLCJzZXRDdXJyZW50V29yZCIsInJlcHJvZHVjZWQiLCJ1bnJlcHJvZHVjZWQiLCJzcGVha2luZyIsImxhc3RXb3JkU2l6ZSIsInNsaWNlIiwiY3VycmVudFdvcmQiLCJzcGxpdCIsImxlbmd0aCIsInVwZGF0ZSIsInBhdXNlZCIsIm9uIiwib2ZmIiwiY29udGFpbmVyIiwiY3VycmVudCIsIndpbmRvdyIsImFzZCIsImhlaWdodCIsImNsb3Nlc3QiLCJjbGllbnRIZWlnaHQiLCJzdHlsZSIsImhhbmRsZUhpZGRlbiIsInJlZiIsImNsYXNzTmFtZSIsIm9uQ2xpY2siLCJoYW5kbGVSZXByb2R1Y3Rpb25DbGljayIsInJlc3VtZSIsInBhdXNlIiwic3BlYWsiLCJkaXNhYmxlZCIsImV4cG9ydHMiLCJMYXN0TWVzc2FnZSIsInVzZXJNZXNzYWdlIiwic2V0VXNlck1lc3NhZ2UiLCJsYXN0TWVzc2FnZSIsInVzZXIiLCJhc3Npc3RhbnRNZXNzYWdlIiwic2V0QXNzaXN0YW50TWVzc2FnZSIsImhhbmRsZUNoYW5nZSIsInBhcmVudEVsZW1lbnQiLCJVc2VyTWVzc2FnZSIsImluZGV4IiwiaXNFZGl0aW5nIiwic2V0SXNFZGl0aW5nIiwic2hvd0FjdGlvbnMiLCJzZXRTaG93QWN0aW9ucyIsInRleHRSZWYiLCJmb2N1cyIsImhhbmRsZVRleHRDbGljayIsImhhbmRsZUNvbmZpcm0iLCJpbm5lclRleHQiLCJoYW5kbGVDYW5jZWwiLCJoYW5kbGVCbHVyIiwiZXZlbnQiLCJyZWxhdGVkVGFyZ2V0IiwidGFyZ2V0IiwidGFnTmFtZSIsImtleSIsImNvbnRlbnRFZGl0YWJsZSIsIm9uQmx1ciIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiX19odG1sIiwiVXNlck1lc3NhZ2VBY3Rpb25zIiwib25Db25maXJtIiwib25DYW5jZWwiLCJ0YXJnZXRFbGVtZW50IiwibWVzc2FnZVJlZiIsInBvc2l0aW9uUmVmIiwibWVzc2FnZUhlaWdodCIsInRhcmdldFJlY3QiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJib3R0b21TcGFjZSIsImlubmVySGVpZ2h0IiwiYm90dG9tIiwidG9wU3BhY2UiLCJ0b3AiLCJDb252ZXJzYXRpb24iLCJtZXNzYWdlcyIsInNldE1lc3NhZ2VzIiwiZ29hbHNTaG93Iiwic2V0R29hbHNTaG93IiwiZ29hbHMiLCJhc3NpZ25tZW50IiwiaGFuZGxlR29hbHNTaG93IiwibWFwIiwibGluZSIsIm1lc3NhZ2UiLCJyb2xlIiwiY29udGVudCIsIlJlY29yZGVyIiwicmVjb3JkZXIiLCJpc1JlY29yZGluZyIsInNldElzUmVjb3JkaW5nIiwicmVjb3JkaW5nIiwiaXNUcmFuc2NyaWJpbmciLCJzZXRJc1RyYW5zY3JpYmluZyIsInRyYW5zY3JpYmluZyIsImhhbmRsZVN0YXJ0IiwicmVjb3JkIiwiaGFuZGxlU3RvcCIsInN0b3AiLCJoYW5kbGVDb250ZXh0TWVudSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm9uTW91c2VEb3duIiwib25Nb3VzZVVwIiwib25Ub3VjaFN0YXJ0Iiwib25Ub3VjaEVuZCIsIm9uS2V5RG93biIsIm9uS2V5VXAiLCJvbkNvbnRleHRNZW51IiwiQXNzaXN0YW50Q29tcG9uZW50IiwiTWVzc2FnZXMiLCJQYWdlIiwidXJpIiwidmFycyIsImFzc2lnbm1lbnRzIiwiZ2V0IiwiQXNzaXN0YW50IiwiQ29udHJvbGxlciIsIlBhZ2VSZWFjdFdpZGdldENvbnRyb2xsZXIiLCJXaWRnZXQiXSwic291cmNlUm9vdCI6IkU6XFx3b3Jrc3BhY2VcXGFpbXBhY3QvIiwic291cmNlcyI6WyJBc3Npc3RhbnQvTGFzdE1lc3NhZ2UvQXNzaXN0YW50TWVzc2FnZS50c3giLCJBc3Npc3RhbnQvTGFzdE1lc3NhZ2UvaW5kZXgudHN4IiwiQXNzaXN0YW50L01lc3NhZ2VzL1VzZXJNZXNzYWdlLnRzeCIsIkFzc2lzdGFudC9NZXNzYWdlcy9Vc2VyTWVzc2FnZUFjdGlvbnMudHN4IiwiQXNzaXN0YW50L01lc3NhZ2VzL2luZGV4LnRzeCIsIkFzc2lzdGFudC9SZWNvcmRlci50c3giLCJBc3Npc3RhbnQvaW5kZXgudHN4IiwiUGFnZS50c3giLCJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6W251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXX0=