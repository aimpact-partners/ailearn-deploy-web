System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      _export("default", {
        "package": "@ai-clase/demo",
        "version": "0.0.1",
        "languages": {
          "supported": [],
          "default": "en"
        },
        "global.css": true,
        "layout": "main-layout",
        "params": {},
        "ssr": {},
        "backend": {}
      });
    }
  };
});